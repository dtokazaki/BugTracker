import boto3
from boto3 import resource
from boto3.dynamodb.conditions import Key
from passlib.hash import pbkdf2_sha256

# Create God account
def createGod(event,context):
    # Create a DynamoDB resource
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('okazakibruce2019')
    
    username = event['username']
    password = event['password']
    
    response = table.query(
        IndexName='username-index',
        KeyConditionExpression=Key('username').eq(username)
    )
    try:
        username = response["Items"][0]['username']
        return -1
    except:
        god_id = pbkdf2_sha256.encrypt(password, rounds=100, salt_size=16)
    
        data = {}
        data['god_id']= god_id
        data['username'] = username
        data['god'] = {}
        data['god']['log'] = []
        data['guardian'] = {}
        data['children'] = {}
        data['child_count'] = 0
        data['avail_child'] = []
        data['accounts'] = {}
        
        
        table.put_item(Item= data)
        return god_id